GOLD Mateusz Złoty — paczka gotowa do wrzucenia na Netlify

Co wgrać:
- wrzuć CAŁĄ zawartość tego folderu do Netlify
- strona główna: /
- wersja angielska: /en/
- wersja czeska: /cs/
- strony podziękowania:
  - /thank-you/
  - /en/thank-you/
  - /cs/thank-you/

Co jest już ustawione:
- responsywna wersja na komputer i telefon
- 3 języki z osobnymi adresami URL
- formularz wysyła wiadomości na: gold.mz@o2.pl
- po wysłaniu formularza użytkownik trafia na właściwą stronę podziękowania
- robots.txt
- sitemap.xml
- canonical i hreflang
- meta title / description / Open Graph
- dane strukturalne JSON-LD
- netlify.toml

Uwagi:
- thank-you pages mają noindex
- sitemap obejmuje tylko strony, które powinny być indeksowane
- robots.txt wskazuje sitemap.xml
